<template>
    <div>
        브랜드 상세보기<hr>
        브랜드 이름<br>
        매출<br>
        개점률, 폐점률<br>
        etc...<br>
        그래프 그려넣기
    </div>
</template>

<script>
export default {
    
}
</script>

<style>

</style>