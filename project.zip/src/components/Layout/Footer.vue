<template>
    <div>
        하단부분
    </div>
</template>

<script>
export default {
    name: 'Footer',
    data(){
        return {
            
        }
    }
}
</script>

<style>

</style>