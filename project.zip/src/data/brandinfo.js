export default{
    Brands:[
        {
            type: '한식',
            brandname: '국사랑',
            fran_month: '95',
            fran_num: '29',
            average_sale: '269167',
            startup_cost: '52600',
            openrate: '17.24',
            closerate: '51.72',
        },
        {
            type: '한식',
            brandname: '삼육가',
            fran_month: '66',
            fran_num: '5',
            average_sale: '1540660',
            startup_cost: '100448',
            openrate: '0',
            closerate: '40',
        },
        {
            type: '한식',
            brandname: '두찜',
            fran_month: '56',
            fran_num: '263',
            average_sale: '240278',
            startup_cost: '47000',
            openrate: '62.74',
            closerate: '11.03',
        }
    ],
    한식:[
        {
            brandname: '국사랑',
            fran_month: '95',
            fran_num: '29',
            average_sale: '269167',
            startup_cost: '52600',
            openrate: '17.24',
            closerate: '51.72',
        },
        {
            brandname: '삼육가',
            fran_month: '66',
            fran_num: '5',
            average_sale: '1540660',
            startup_cost: '100448',
            openrate: '0',
            closerate: '40',
        },
        {
            type: '한식',
            brandname: '두찜',
            fran_month: '56',
            fran_num: '263',
            average_sale: '240278',
            startup_cost: '47000',
            openrate: '62.74',
            closerate: '11.03',
        },
    ]
}